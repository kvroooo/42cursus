gcc -c *.c
ar r libft.a *.o
